<template>
    <div class="w-100 h-100" style="background-color: rgb(229, 229, 229);">
        <NavBar />
        <slot></slot>
    </div>
</template>
