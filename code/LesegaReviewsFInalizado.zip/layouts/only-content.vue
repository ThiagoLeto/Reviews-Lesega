<template>
    <div class="w-100 h-100">
        <slot></slot>
    </div>
</template>
